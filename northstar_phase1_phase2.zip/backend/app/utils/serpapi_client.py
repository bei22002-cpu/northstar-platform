# SerpAPI client pseudocode (Specification)
