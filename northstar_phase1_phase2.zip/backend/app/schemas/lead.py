# Lead schemas (Specification)
