# Lead model (Specification)
