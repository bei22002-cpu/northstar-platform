# User model (Specification)
