# Lead classifier pseudocode (Specification)
